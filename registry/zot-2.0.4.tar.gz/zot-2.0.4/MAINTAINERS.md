# zot Maintainers

## Maintainers

| Maintainer | Github ID | Affiliation |
| --------------- | --------- | ----------- |
| Ramkumar Chinchani | [rchincha](https://github.com/rchincha) | [Cisco Systems](https://www.cisco.com) |
| Ravi Chamarthy | [rchamarthy](https://github.com/rchamarthy) | [Cisco Systems](https://www.cisco.com) |
| Serge Hallyn | [hallyn](https://github.com/hallyn) | [Cisco Systems](https://www.cisco.com) |
| Andrei Aaron | [andaaron](https://github.com/andaaron) | [Luxoft](https://www.luxoft.com/) | 
| Tycho Andersen | [tych0](https://github.com/tych0) | [Netflix](https://www.netflix.com) |
