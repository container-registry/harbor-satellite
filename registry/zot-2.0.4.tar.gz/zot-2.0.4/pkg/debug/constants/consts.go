package constants

const (
	Debug                 = "/_zot/debug"
	GQLPlaygroundEndpoint = Debug + "/graphql-playground"
	ProfilingEndpoint     = "/_zot/pprof/"
)
