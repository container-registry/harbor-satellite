package constants

// references type.
const (
	Cosign            = "CosignSignature"
	OCI               = "OCIReference"
	Tag               = "TagReference"
	SyncBlobUploadDir = ".sync"
)
